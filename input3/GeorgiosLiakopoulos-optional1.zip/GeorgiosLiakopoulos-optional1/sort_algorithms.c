
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void swap(int *A, int *b)
{
    int temp = *A;
    *A = *b;
    *b = temp;
}

void bubbleSort(int A[], int size) /* bubble sort function */
{
    int temp,i;
    if (size == 1)
        return; 
    for (i = 0; i < size-1; i++) 
        if (A[i] > A[i+1])
        {
            swap(&A[i],&A[i+1]);
        }
   
   bubbleSort(A,size-1); /*recursion*/
}

int minIndex(int A[], int i, int j) /*find the min from index i to the end of the array*/
{
    if (i == j)
        return i;
 
    int k = minIndex(A ,i + 1, j);
    
    if(A[i]<A[k])
        return i;
    else    
        return k;
}

void SelectionSort(int A[], int size, int index ) /*section sort function */
{
    if (index == size)
       return;
 
    int k = minIndex(A, index, size-1);
 
    if (k != index)
       swap(&A[k], &A[index]);
 
    
    SelectionSort(A, size, ++index); /* recursion */
}

void insertionSort(int A[], int size) /* insertion sort function */
{
    int i, key, j;
    for (i = 1; i < size; i++)
    {
        key = A[i];
        j = i-1;
        while (j >= 0 && A[j] > key)
        {
            A[j+1] = A[j];
            j = j-1;
        }
        A[j+1] = key;
    }
}

int binarySearch(int A[], int item, int i, int j) /*find the min with binary search*/
{
    if (j <= i)
        if(item>A[i])
            return i+1;
        else    
            return i;
    
    int m = (i + j)/2;
 
    if(item == A[m])
        return m+1;
 
    if(item > A[m])
        return binarySearch(A, item, m+1, j);
    
    return binarySearch(A, item, i, m-1);
}

void  BinaryinsertionSort(int A[], int size) /*insertion sort with binary search */
{
    int i, pst, j, k, wanted;
 
    for (i = 1; i <  size ; ++i){
        j = i - 1;
        wanted = A[i];
        pst = binarySearch(A, wanted, 0, j);
        while (j >= pst){
            A[j+1] = A[j];
            j--;
        }
        A[j+1] = wanted;
    }
}


void printArrAy(int A[], int size) /*function to print the array */
{
    int i;
    for (i=0; i < size; i++)
        printf("%d ", A[i]);
    printf("\n");
} 

int main()
{
	int size;
	printf("Give the size of the array: ");
	scanf("%d",&size);

    int *A,i;
    srand(time(NULL));
    A = malloc( size *sizeof(int));

/*--------------------------------------------------------------------------------------*/

    for(i=0;i< size ;i++){   /*filling the array with random int's smaller than 10000 */
        A[i]=rand()%10000;
    }

    clock_t begin = clock();
    bubbleSort(A,size);		/*bubble sort*/
	clock_t end = clock();
	double time_spent = (double)(end - begin) / CLOCKS_PER_SEC;
	printf("Recursive Bubble Sort:\n  ------->Execution time: %lf sec\n",time_spent); /*information */

/*--------------------------------------------------------------------------------------*/


    for(i=0;i< size ;i++){   /*filling the array with random int's smaller than 10000 */
        A[i]=rand()%10000;
    }

    begin = clock();
    SelectionSort(A,size,0);		//selection sort
	end = clock();
	time_spent = (double)(end - begin) / CLOCKS_PER_SEC;
	printf("Recursive Selection Sort:\n  ------->Execution time: %lf sec\n",time_spent); /* information */


/*--------------------------------------------------------------------------------------*/    

    for(i=0;i< size ;i++){   /*filling the array with random int's smaller than 10000 */
        A[i]=rand()%10000;
    }

    begin = clock();
    insertionSort(A,size);		//insertion sort
	end = clock();
	time_spent = (double)(end - begin) / CLOCKS_PER_SEC;
	printf("Insertion Sort:\n  ------->Execution time: %lf sec\n",time_spent); /*information */

/*--------------------------------------------------------------------------------------*/    

    for(i=0;i< size ;i++){   /*filling the array with random int's smaller than 10000 */
        A[i]=rand()%10000;
    }

    begin = clock();
    BinaryinsertionSort(A,size);		//insertion sort with binary search
	end = clock();
	time_spent = (double)(end - begin) / CLOCKS_PER_SEC;
	printf("Insertion Sort with binary search:\n  ------->Execution time: %lf sec\n",time_spent); /*information*/

    free(A);
    return 0;
}
